package com.resourceRequirement.resourceRequirement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceRequirementApplicationTests {

	@Test
	void contextLoads() {
	}

}

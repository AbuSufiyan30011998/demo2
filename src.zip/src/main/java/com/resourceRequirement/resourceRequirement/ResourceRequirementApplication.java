package com.resourceRequirement.resourceRequirement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourceRequirementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceRequirementApplication.class, args);
	}

}

package com.resourceRequirement.resourceRequirement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourceRequirement.resourceRequirement.model.DomainKnowledge;

public interface DomainRepository extends JpaRepository<DomainKnowledge, Long>{

}
